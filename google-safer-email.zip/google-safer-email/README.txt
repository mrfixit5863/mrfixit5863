google-starttls-percentages.csv

This file contains the overall percentage of email exchanged between Gmail and
other providers that was encrypted, for each day since the report began.


google-starttls-domains.csv

This file contains, for the most recent day reported, the approximate percentage
encrypted for each “bucket” of email large enough to be reported upon.


See https://transparencyreport.google.com/safer-email/overview for more
information.
